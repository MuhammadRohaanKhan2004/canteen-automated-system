package tests;

import static org.junit.Assert.assertNull;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.fail;

import java.lang.reflect.Field;

import javax.swing.JLabel;
import javax.swing.JTextField;

import org.junit.Assert;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import ia.Email;
import ia.Homepage;
import ia.InventoryItem;
import ia.Login;
import ia.Registration;

import ia.Order;
class unittest1 {

    private Login login;
	private Object email;
	@BeforeAll
    static void setUpBeforeClass() throws Exception {
    }

    @AfterAll
    static void tearDownAfterClass() throws Exception {
    }

    @BeforeEach
    void setUp() throws Exception {
        login = new Login(); // Instantiate the Login class
    }

    @AfterEach
    void tearDown() throws Exception {
    }

    @Test
    void testValidLogin() {
        assertTrue(login.validateLogin("cafe", "000000"));
    }

    @Test
    void testInvalidUsername() {
        assertFalse(login.validateLogin("invalid", "000000"));
    }

    @Test
    void testInvalidPassword() {
        assertFalse(login.validateLogin("cafe", "wrongpassword"));
    }

    @Test
    void testInvalidUsernameAndPassword() {
        assertFalse(login.validateLogin("invalid", "wrongpassword"));
    }

    @Test
    void testRegistrationForm() {
        Registration registration = new Registration();

        // Simulate user input
        JTextField fullNameField = getField(registration, "textField_1");
        fullNameField.setText("John Doe");

        JTextField emailField = getField(registration, "textField_2");
        emailField.setText("johndoe@example.com");

        JTextField usernameField = getField(registration, "textField_3");
        usernameField.setText("johndoe");

        JTextField passwordField = getField(registration, "textField_4");
        passwordField.setText("password");

        JTextField confirmPasswordField = getField(registration, "textField_5");
        confirmPasswordField.setText("password");

        // Simulate button click to confirm registration
        registration.testRegistration();

        // Optionally, you can assert further based on expected behavior or validation
        // For example:
        // - Check if the registration was successful
        // - Check if appropriate messages are displayed on success or failure
    }

    // Helper method to access private fields in Registration class
    private JTextField getField(Registration registration, String fieldName) {
        try {
            Field field = Registration.class.getDeclaredField(fieldName);
            field.setAccessible(true);
            return (JTextField) field.get(registration);
        } catch (Exception e) {
            fail("Failed to access field: " + fieldName);
            return null;
        }
    }
        @Test
        void testGenerateCode() {
            Email emailFrame = new Email();

            // Simulate user input
            JTextField emailTextField = getField(emailFrame, "textField");
            emailTextField.setText("test@gmail.com"); // Replace with a valid email for testing

            // Trigger code generation
            emailFrame.generateCode();

            // Get the generated code from the UI
            JTextField codeTextField = getField(emailFrame, "textField_1");
            String generatedCode = codeTextField.getText();

            // Verify the generated code
            assertNotNull(generatedCode);
            assertTrue(generatedCode.matches("\\d{6}")); // Ensure it's a 6-digit number

            // Optionally, you can further validate the logic of generateCode() method
            // For example, check if an invalid email produces an error message
        }

        private void assertNotNull(String generatedCode) {
			// TODO Auto-generated method stub
			
		}

		// Helper method to access private fields in Email class
        private JTextField getField(Email emailFrame, String fieldName) {
            try {
                java.lang.reflect.Field field = Email.class.getDeclaredField(fieldName);
                field.setAccessible(true);
                return (JTextField) field.get(emailFrame);
            } catch (Exception e) {
                fail("Failed to access field: " + fieldName);
                return null;
            }
    }

		public Object getEmail() {
			return email;
		}

		public void setEmail(Object email) {
			this.email = email;
		}
		   @Test
		    void testHomepage() {
		        Homepage homepage = new Homepage();
		        homepage.setVisible(true);

		        try {
		            JLabel menuLabel = (JLabel) getField(homepage, "menuLabel");
		            Assert.assertNotNull(menuLabel);
		            assertEquals("MENU", menuLabel.getText());
		        } catch (Exception e) {
		            fail("Exception occurred while accessing menuLabel: " + e.getMessage());
		        }
		    }

		    private Object getField(Object object, String fieldName) {
		        try {
		            Field field = object.getClass().getDeclaredField(fieldName);
		            field.setAccessible(true);
		            return field.get(object);
		        } catch (NoSuchFieldException | IllegalAccessException e) {
		            fail("Failed to access field: " + fieldName);
		            return null;
		                }
		          }
	
		    @Test
		    public void testCalculateTotal() {
		        Order order = new Order("Burger", 5.99, 2);
		        double expectedTotal = 5.99 * 2;
		        Assert.assertEquals(expectedTotal, order.calculateTotal(), 0.001);
		    }

		    @Test
		    public void testOrderDetails() {
		        Order order = new Order("Pizza", 8.99, 1);
		        
		        assertEquals("Pizza", order.getItemName());
		        assertEquals(8.99, order.getItemName(), 0.001);
		        assertEquals(1, order.getQuantity());
		    }

			private void assertEquals(String string, Object object) {
				// TODO Auto-generated method stub
				
			}

			private void assertEquals(int i, int j) {
				// TODO Auto-generated method stub
				
			}

			private void assertEquals(double d, String string, double e) {
				// TODO Auto-generated method stub
				
			}

			
			    @Test
			    public void testAddItem() {
			        InventoryItem.InventoryManagement inventory = new InventoryItem.InventoryManagement();
			        
			        // Add an item
			        inventory.addItem(new InventoryItem.BurgerItem("Test Burger", 10));
			        
			        // Check if the item is added correctly
			        Assert.assertNotNull(inventory.getItem("Test Burger"));
			        assertEquals(10, inventory.getItem("Test Burger").getQuantity());
			    }

			    @Test
			    public void testRemoveItem() {
			        InventoryItem.InventoryManagement inventory = new InventoryItem.InventoryManagement();
			        
			        // Add an item and then remove it
			        inventory.addItem(new InventoryItem.BurgerItem("Test Burger", 10));
			        inventory.removeItem("Test Burger", 5);
			        
			        // Check if the quantity is updated correctly
			        assertEquals(5, inventory.getItem("Test Burger").getQuantity());
			        
			        // Remove the remaining quantity
			        inventory.removeItem("Test Burger", 5);
			        
			        // Check if the item is removed from the inventory
			        assertNull(inventory.getItem("Test Burger"));
			    }

			    @Test
			    public void testDisplayInventory() {
			        InventoryItem.InventoryManagement inventory = new InventoryItem.InventoryManagement();
			        
			        // Add items to the inventory
			        inventory.addItem(new InventoryItem.BurgerItem("Burger Buns", 50));
			        inventory.addItem(new InventoryItem.PizzaItem("Pizza Dough", 20));
			        
			        // Capture the inventory display output
			        String inventoryDisplay = captureInventoryDisplay(inventory);
			        
			        // Check if the inventory display contains the added items
			        assertTrue(inventoryDisplay.contains("Item: Burger Buns, Quantity: 50"));
			        assertTrue(inventoryDisplay.contains("Item: Pizza Dough, Quantity: 20"));
			    }

			    // Helper method to capture the inventory display output
			    private String captureInventoryDisplay(InventoryItem.InventoryManagement inventory) {
			        StringBuilder output = new StringBuilder();
			        for (InventoryItem.InventoryItem1 item : inventory.inventory.values()) {
			            output.append(item.toString()).append("\n");
			        }
			        return output.toString();
			   
			    }
			    
}