package ia;

import java.util.HashMap;
import java.util.Map;

public class InventoryItem {
    // Base class for Inventory Items
    public static class InventoryItem1 {
        private String name;
        private int quantity;

        public InventoryItem1(String name, int quantity) {
            this.name = name;
            this.quantity = quantity;
        }

        public String getName() {
            return name;
        }

        public int getQuantity() {
            return quantity;
        }

        public void setQuantity(int quantity) {
            this.quantity = quantity;
        }

        @Override
        public String toString() {
            return "Item: " + name + ", Quantity: " + quantity;
        }
    }

    // Specific classes for different item types
    public static class BurgerItem extends InventoryItem1 {
        public BurgerItem(String name, int quantity) {
            super(name, quantity);
        }
    }

    public static class PizzaItem extends InventoryItem1 {
        public PizzaItem(String name, int quantity) {
            super(name, quantity);
        }
    }

    static class SideItem extends InventoryItem1 {
        public SideItem(String name, int quantity) {
            super(name, quantity);
        }
    }

    static class BeverageItem extends InventoryItem1 {
        public BeverageItem(String name, int quantity) {
            super(name, quantity);
        }
    }

    static class CondimentItem extends InventoryItem1 {
        public CondimentItem(String name, int quantity) {
            super(name, quantity);
        }
    }

    // Inventory Management class
    public static class InventoryManagement {
        public Map<String, InventoryItem1> inventory;

        public InventoryManagement() {
            inventory = new HashMap<>();
        }

        public void addItem(InventoryItem1 item) {
            if (inventory.containsKey(item.getName())) {
                InventoryItem1 existingItem = inventory.get(item.getName());
                existingItem.setQuantity(existingItem.getQuantity() + item.getQuantity());
            } else {
                inventory.put(item.getName(), item);
            }
        }

        public void removeItem(String name, int quantity) {
            if (inventory.containsKey(name)) {
                InventoryItem1 item = inventory.get(name);
                int newQuantity = item.getQuantity() - quantity;
                if (newQuantity <= 0) {
                    inventory.remove(name);
                } else {
                    item.setQuantity(newQuantity);
                }
            } else {
                System.out.println("Item not found in inventory.");
            }
        }

        public InventoryItem1 getItem(String name) {
            return inventory.get(name);
        }

        public void displayInventory() {
            for (InventoryItem1 item : inventory.values()) {
                System.out.println(item);
            }
        }
    }

    // Main method to test the inventory management system
    public static void main(String[] args) {
        InventoryManagement inventory = new InventoryManagement();

        // Adding burger items
        inventory.addItem(new BurgerItem("Ground beef patties", 50));
        inventory.addItem(new BurgerItem("Burger buns", 100));
        inventory.addItem(new BurgerItem("Cheese slices", 200));

        // Adding pizza items
        inventory.addItem(new PizzaItem("Pizza dough", 30));
        inventory.addItem(new PizzaItem("Pizza sauce", 50));
        inventory.addItem(new PizzaItem("Mozzarella cheese", 100));

        // Adding side items
        inventory.addItem(new SideItem("Frozen fries", 200));
        inventory.addItem(new SideItem("Onion rings", 150));

        // Adding beverages
        inventory.addItem(new BeverageItem("Soda", 300));
        inventory.addItem(new BeverageItem("Water", 200));

        // Adding condiments
        inventory.addItem(new CondimentItem("Ketchup", 100));
        inventory.addItem(new CondimentItem("Mustard", 100));

        // Displaying inventory
        inventory.displayInventory();

        // Removing some items
        inventory.removeItem("Ground beef patties", 10);
        inventory.removeItem("Pizza dough", 5);

        // Displaying inventory after removal
        System.out.println("\nInventory after removing some items:");
        inventory.displayInventory();
    }

	public static void addItem(BurgerItem burgerItem) {
		// TODO Auto-generated method stub
		
	}

	public static Order getItem(String string) {
		// TODO Auto-generated method stub
		return null;
	}

	public static void removeItem(String string, int i) {
		// TODO Auto-generated method stub
		
	}

	public static void displayInventory() {
		// TODO Auto-generated method stub
		
	}

	public static void addItem(PizzaItem pizzaItem) {
		// TODO Auto-generated method stub
		
	}
}
